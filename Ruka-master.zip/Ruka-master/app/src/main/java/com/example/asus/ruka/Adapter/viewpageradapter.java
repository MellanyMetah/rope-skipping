package com.example.asus.ruka.Adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.asus.ruka.Fragments.About;
import com.example.asus.ruka.Fragments.Play;
import com.example.asus.ruka.Fragments.msetting;

/**
 * This call is used to poplulate the vviewpager with fragments
 * this class inherits some methods from th frgaamnetpager adapter
*/
public class viewpageradapter extends FragmentPagerAdapter {
    Context context;

    public viewpageradapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    /**
     * we populte and intatiate our fragments
     * @param position
     * @return
     */
    @Override
    public Fragment getItem(int position) {
        switch  (position){
            case 1: return new About();
            case 2: return new Play();
            case 3:return new msetting()    ;
            default: return new msetting();
        }
    }
//total number of fragmnets are 3 for our case
    @Override
    public int getCount() {
        return 3;
    }
}
