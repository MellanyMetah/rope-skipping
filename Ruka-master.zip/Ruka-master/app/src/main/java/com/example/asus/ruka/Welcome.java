package com.example.asus.ruka;

import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.paolorotolo.appintro.AppIntroFragment;

public class Welcome extends com.github.paolorotolo.appintro.AppIntro {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addSlide(AppIntroFragment.newInstance("Ruka","Lets jump high high ",R.drawable.ruka, Color.parseColor("#3F51B5")));
        addSlide(AppIntroFragment.newInstance("2nd screen","Lets jump high high ",R.drawable.ruka, Color.parseColor("#3F51B5")));
        addSlide(AppIntroFragment.newInstance("3rd screen","Lets jump high high ",R.drawable.ruka, Color.parseColor("#3F51B5")));
        setBarColor(Color.parseColor("#3F51B5"));
        setSeparatorColor(Color.parseColor("#2196F3"));
        setSlideOverAnimation();
    }
    @Override
    public void onSkipPressed(Fragment currentFragment){
        super.onSkipPressed(currentFragment);
        gotoHome();
    }
    /*
     * This method launches the Home activity*/
    private void gotoHome() {
        startActivity(new Intent(Welcome.this,GameHome.class));
    }

    @Override
    public void onDonePressed(Fragment currentFragment){
        super.onDonePressed(currentFragment);
        gotoHome();
    }
}



