package com.example.asus.ruka.Fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.asus.ruka.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class About extends Fragment {

    private int[] Layouts = new int[]{R.layout.slide_1, R.layout.slide_2, R.layout.slide_3};
    private View view;

    private ViewPager viewpager;

    public About() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_about, container, false);
        initView(view);
        return view;
    }

    private void initView(View view) {
        viewpager = (ViewPager) view.findViewById(R.id.viewpager);
        viewpager.setAdapter(new viewpagerAdater());
        viewpager.setCurrentItem(0);
    }


    /**
     * This is a custom viewpager adapter that populates the welcome screen
     */
    class viewpagerAdater extends PagerAdapter {

        @Override
        public int getCount() {
            return Layouts.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view==object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(Layouts[position], null);
            container.addView(view);
            return view;

        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }
}
